<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="resources/css/estilos.css">

    <h1>Presentin TM</h1>
    </header>
    <main>
        <h2 id=»inicio»></h2>
        <h2 id=»productos»></h2>
        <h2 id=»contacto»></h2>
    </main>
    <button type="button" onclick="location.href='http://localhost/Asistencias/materiaManager.php'">Asistencias</button>
    <button type="button" onclick="location.href='http://localhost/Asistencias/altas.php'"> Alta </button>
   
    

    </body>

</html>